# Brazen Benosa — Futuristic Portfolio

Files included:
- `index.html` — standard webpage
- `style.css` — complete stylesheet
- `script.js` — JavaScript interactions (mobile navigation, scroll reveal, current year)
- `index-standalone.html` — single-file version with CSS and JavaScript embedded

Keep `index.html`, `style.css`, and `script.js` in the same folder for the standard version. Alternatively, rename `index-standalone.html` to `index.html` and publish just that file.

## GitHub Pages
Upload the standard three files to the repository root, or upload the standalone file renamed to `index.html`. Then go to Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
